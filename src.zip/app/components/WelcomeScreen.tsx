import { useNavigate } from "react-router";
import { Shield, Search } from "lucide-react";
import { Button } from "./ui/button";

export function WelcomeScreen() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col items-center justify-center px-6 max-w-md mx-auto">
      {/* Logo */}
      <div className="relative mb-8">
        <div className="w-32 h-32 bg-[#2563EB] rounded-3xl flex items-center justify-center shadow-2xl shadow-blue-500/30">
          <div className="relative">
            <Shield className="w-16 h-16 text-white absolute -left-2 -top-2" strokeWidth={2} />
            <Search className="w-16 h-16 text-white absolute left-4 top-4" strokeWidth={2.5} />
          </div>
        </div>
      </div>

      {/* App Name */}
      <h1 className="text-5xl font-bold text-gray-900 mb-3">TruthLens</h1>

      {/* Tagline */}
      <p className="text-xl text-gray-600 mb-12">Verify before you trust</p>

      {/* Features */}
      <div className="space-y-4 mb-12 w-full">
        <div className="flex items-center gap-3 bg-white p-4 rounded-xl shadow-sm">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            <Search className="w-5 h-5 text-[#2563EB]" />
          </div>
          <div>
            <p className="font-medium text-gray-900">AI-Powered Analysis</p>
            <p className="text-sm text-gray-500">Instant credibility check</p>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-white p-4 rounded-xl shadow-sm">
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
            <Shield className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <p className="font-medium text-gray-900">Trusted Sources</p>
            <p className="text-sm text-gray-500">Verified information only</p>
          </div>
        </div>
      </div>

      {/* Get Started Button */}
      <Button
        onClick={() => navigate("/home")}
        className="w-full h-14 bg-[#2563EB] hover:bg-blue-700 text-white text-lg font-semibold rounded-2xl shadow-lg shadow-blue-500/30"
      >
        Get Started
      </Button>

      <p className="text-sm text-gray-500 mt-8">For university students • Free to use</p>
    </div>
  );
}
