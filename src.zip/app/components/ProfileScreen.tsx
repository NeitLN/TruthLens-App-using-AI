import { useState } from "react";
import { User, Bell, Shield, Info, ChevronRight, Mail, Settings } from "lucide-react";
import { Switch } from "./ui/switch";

export function ProfileScreen() {
  const [notifications, setNotifications] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(false);
  const [dataSharing, setDataSharing] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 pb-6">
      {/* Header */}
      <div className="bg-[#2563EB] text-white px-6 pt-12 pb-8 rounded-b-3xl">
        <h1 className="text-3xl font-bold mb-2">Profile</h1>
        <p className="text-blue-100">Manage your settings and preferences</p>
      </div>

      <div className="px-6 -mt-6 space-y-4">
        {/* User Profile Card */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Student User</h2>
              <p className="text-sm text-gray-500">student@university.edu</p>
            </div>
          </div>
          <button className="w-full py-2 text-[#2563EB] font-medium hover:bg-blue-50 rounded-lg transition-colors">
            Edit Profile
          </button>
        </div>

        {/* Notifications Section */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center">
              <Bell className="w-5 h-5 text-orange-600" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">Notifications</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="font-medium text-gray-900">Push Notifications</p>
                <p className="text-sm text-gray-500">Get alerts for analysis results</p>
              </div>
              <Switch checked={notifications} onCheckedChange={setNotifications} />
            </div>

            <div className="flex items-center justify-between py-2 border-t border-gray-100">
              <div>
                <p className="font-medium text-gray-900">Email Alerts</p>
                <p className="text-sm text-gray-500">Receive weekly summaries</p>
              </div>
              <Switch checked={emailAlerts} onCheckedChange={setEmailAlerts} />
            </div>
          </div>
        </div>

        {/* Privacy Settings */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-green-600" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">Privacy & Security</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="font-medium text-gray-900">Data Sharing</p>
                <p className="text-sm text-gray-500">Help improve our AI models</p>
              </div>
              <Switch checked={dataSharing} onCheckedChange={setDataSharing} />
            </div>

            <button className="w-full flex items-center justify-between py-3 border-t border-gray-100 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-900">Privacy Policy</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            <button className="w-full flex items-center justify-between py-3 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-900">Terms of Service</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {/* About Section */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <Info className="w-5 h-5 text-[#2563EB]" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">About TruthLens</h3>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-gray-600">Version</span>
              <span className="text-sm font-medium text-gray-900">1.0.0</span>
            </div>
            <div className="flex items-center justify-between py-2 border-t border-gray-100">
              <span className="text-sm text-gray-600">Build</span>
              <span className="text-sm font-medium text-gray-900">2025.03</span>
            </div>

            <button className="w-full py-3 mt-2 text-[#2563EB] font-medium hover:bg-blue-50 rounded-lg transition-colors border-t border-gray-100">
              Help & Support
            </button>
          </div>
        </div>

        {/* Sign Out */}
        <button className="w-full py-4 bg-white text-red-600 font-semibold rounded-xl shadow-sm hover:bg-red-50 transition-colors">
          Sign Out
        </button>

        {/* Footer */}
        <p className="text-center text-xs text-gray-400 pt-4">
          Made for university students • Verify before you trust
        </p>
      </div>
    </div>
  );
}
