import { useParams, useNavigate } from "react-router";
import { CheckCircle, AlertTriangle, XCircle, ArrowLeft, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import { getAnalysisById } from "../utils/analysis";

export function ResultScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const result = id ? getAnalysisById(id) : null;

  if (!result) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">Result not found</p>
      </div>
    );
  }

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "trusted":
        return {
          icon: <CheckCircle className="w-20 h-20" />,
          color: "text-green-500",
          bg: "bg-green-50",
          border: "border-green-200",
          label: "Trusted",
        };
      case "suspicious":
        return {
          icon: <AlertTriangle className="w-20 h-20" />,
          color: "text-yellow-500",
          bg: "bg-yellow-50",
          border: "border-yellow-200",
          label: "Suspicious",
        };
      case "fake":
        return {
          icon: <XCircle className="w-20 h-20" />,
          color: "text-[#EF4444]",
          bg: "bg-red-50",
          border: "border-red-200",
          label: "Fake News",
        };
      default:
        return {
          icon: <AlertTriangle className="w-20 h-20" />,
          color: "text-gray-500",
          bg: "bg-gray-50",
          border: "border-gray-200",
          label: "Unknown",
        };
    }
  };

  const config = getStatusConfig(result.status);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <button
          onClick={() => navigate("/home")}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </button>
      </div>

      {/* Result Content */}
      <div className="px-6 py-8">
        {/* Status Card */}
        <div className={`${config.bg} border ${config.border} rounded-3xl p-8 text-center mb-6`}>
          <div className={`${config.color} flex justify-center mb-4`}>
            {config.icon}
          </div>
          <h1 className={`text-3xl font-bold ${config.color} mb-2`}>
            {config.label}
          </h1>
          <p className="text-gray-600 text-sm">Analysis completed</p>
        </div>

        {/* Content Preview */}
        <div className="bg-white rounded-2xl p-6 mb-6 shadow-sm">
          <h3 className="font-semibold text-gray-900 mb-3">Content Analyzed</h3>
          <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">
            {result.content}
          </p>
        </div>

        {/* Explanation */}
        <div className="bg-white rounded-2xl p-6 mb-6 shadow-sm">
          <h3 className="font-semibold text-gray-900 mb-3">Explanation</h3>
          <p className="text-gray-600 text-sm leading-relaxed">
            {result.explanation}
          </p>
        </div>

        {/* Confidence Score */}
        <div className="bg-white rounded-2xl p-6 mb-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-900">Confidence Score</h3>
            <span className="text-2xl font-bold text-[#2563EB]">{result.confidence}%</span>
          </div>
          <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#2563EB] rounded-full transition-all duration-1000"
              style={{ width: `${result.confidence}%` }}
            ></div>
          </div>
          <p className="text-xs text-gray-500 mt-3 text-center">
            Powered by data from Vietnamese news & social media
          </p>
        </div>

        {/* View Details Button */}
        <Button
          onClick={() => navigate(`/detail/${result.id}`)}
          className="w-full h-14 bg-[#2563EB] hover:bg-blue-700 text-white font-semibold rounded-xl"
        >
          View Detailed Analysis
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <Button
            variant="outline"
            onClick={() => navigate("/home")}
            className="h-12 border-gray-300 hover:bg-gray-50 rounded-xl"
          >
            New Check
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate("/history")}
            className="h-12 border-gray-300 hover:bg-gray-50 rounded-xl"
          >
            View History
          </Button>
        </div>
      </div>
    </div>
  );
}