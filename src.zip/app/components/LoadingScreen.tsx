import { Loader2, Brain, Shield, Search } from "lucide-react";

export function LoadingScreen() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col items-center justify-center px-6">
      {/* Animated Spinner */}
      <div className="relative mb-8">
        <div className="w-32 h-32 border-8 border-blue-100 rounded-full"></div>
        <div className="absolute inset-0 w-32 h-32 border-8 border-transparent border-t-[#2563EB] rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <Brain className="w-12 h-12 text-[#2563EB]" />
        </div>
      </div>

      {/* Loading Text */}
      <h2 className="text-2xl font-bold text-gray-900 mb-2">Analyzing Credibility</h2>
      <p className="text-gray-600 mb-12">Using AI to verify your content...</p>

      {/* Processing Steps */}
      <div className="w-full max-w-sm space-y-4">
        <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm animate-pulse">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            <Search className="w-5 h-5 text-[#2563EB]" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-gray-900">Scanning content</p>
            <div className="h-1.5 bg-gray-200 rounded-full mt-2 overflow-hidden">
              <div className="h-full bg-[#2563EB] rounded-full animate-[loading_1.5s_ease-in-out_infinite] w-2/3"></div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm animate-pulse" style={{ animationDelay: "0.3s" }}>
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            <Shield className="w-5 h-5 text-[#2563EB]" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-gray-900">Checking sources</p>
            <div className="h-1.5 bg-gray-200 rounded-full mt-2 overflow-hidden">
              <div className="h-full bg-[#2563EB] rounded-full animate-[loading_1.5s_ease-in-out_infinite] w-1/2" style={{ animationDelay: "0.3s" }}></div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm animate-pulse" style={{ animationDelay: "0.6s" }}>
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            <Loader2 className="w-5 h-5 text-[#2563EB] animate-spin" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-gray-900">Cross-referencing data</p>
            <div className="h-1.5 bg-gray-200 rounded-full mt-2 overflow-hidden">
              <div className="h-full bg-[#2563EB] rounded-full animate-[loading_1.5s_ease-in-out_infinite] w-1/3" style={{ animationDelay: "0.6s" }}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
