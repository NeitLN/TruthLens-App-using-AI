import { useState } from "react";
import { useNavigate } from "react-router";
import { Send, Clock, CheckCircle, AlertTriangle, XCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { analyzeContent, saveAnalysis, getAnalysisHistory } from "../utils/analysis";

export function HomeScreen() {
  const [input, setInput] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const navigate = useNavigate();
  const history = getAnalysisHistory().slice(0, 5); // Show last 5

  const handleAnalyze = async () => {
    if (!input.trim()) return;

    setIsAnalyzing(true);
    navigate("/loading");

    // Simulate AI processing delay
    setTimeout(() => {
      const result = analyzeContent(input);
      saveAnalysis(result);
      setInput("");
      setIsAnalyzing(false);
      navigate(`/result/${result.id}`);
    }, 2500);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "trusted":
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case "suspicious":
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case "fake":
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "trusted":
        return "bg-green-50 border-green-200";
      case "suspicious":
        return "bg-yellow-50 border-yellow-200";
      case "fake":
        return "bg-red-50 border-red-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-6">
      {/* Header */}
      <div className="bg-[#2563EB] text-white px-6 pt-12 pb-8 rounded-b-3xl">
        <h1 className="text-3xl font-bold mb-2">Check Your News</h1>
        <p className="text-blue-100">Paste a link or text to verify credibility</p>
        <div className="mt-3 flex items-center gap-2 text-blue-100 text-xs">
          <div className="w-1.5 h-1.5 bg-blue-200 rounded-full"></div>
          <span>Powered by Vietnamese news & social media data</span>
        </div>
      </div>

      {/* Input Section */}
      <div className="px-6 -mt-6">
        <div className="bg-white rounded-2xl shadow-lg p-5">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste a link or text here..."
            className="min-h-32 border-gray-200 focus:border-[#2563EB] focus:ring-[#2563EB] rounded-xl resize-none"
          />
          <Button
            onClick={handleAnalyze}
            disabled={!input.trim() || isAnalyzing}
            className="w-full mt-4 h-12 bg-[#2563EB] hover:bg-blue-700 text-white font-semibold rounded-xl"
          >
            <Send className="w-5 h-5 mr-2" />
            Analyze Now
          </Button>
        </div>
      </div>

      {/* Recent Checks */}
      {history.length > 0 && (
        <div className="px-6 mt-8">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Recent Checks</h2>
          <div className="space-y-3">
            {history.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(`/result/${item.id}`)}
                className={`w-full text-left bg-white border rounded-xl p-4 transition-all hover:shadow-md ${getStatusColor(
                  item.status
                )}`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getStatusIcon(item.status)}</div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 truncate">{item.title}</p>
                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                      <Clock className="w-4 h-4" />
                      <span>{new Date(item.timestamp).toLocaleDateString()}</span>
                      <span className="capitalize">• {item.status}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {history.length === 0 && (
        <div className="px-6 mt-16 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Clock className="w-10 h-10 text-gray-400" />
          </div>
          <p className="text-gray-500">No recent checks yet</p>
          <p className="text-sm text-gray-400 mt-1">Start analyzing news to see your history</p>
        </div>
      )}
    </div>
  );
}