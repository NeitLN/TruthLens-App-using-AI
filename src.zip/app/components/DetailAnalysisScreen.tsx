import { useParams, useNavigate } from "react-router";
import { ArrowLeft, Shield, FileText, Search, CheckCircle, XCircle, AlertCircle, Database } from "lucide-react";
import { getAnalysisById } from "../utils/analysis";

export function DetailAnalysisScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const result = id ? getAnalysisById(id) : null;

  if (!result) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">Result not found</p>
      </div>
    );
  }

  const getSourceIcon = (status: string) => {
    switch (status) {
      case "trusted":
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case "unknown":
        return <AlertCircle className="w-6 h-6 text-yellow-500" />;
      case "blacklisted":
        return <XCircle className="w-6 h-6 text-red-500" />;
      default:
        return null;
    }
  };

  const getSourceBadge = (status: string) => {
    switch (status) {
      case "trusted":
        return "bg-green-100 text-green-700 border-green-200";
      case "unknown":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "blacklisted":
        return "bg-red-100 text-red-700 border-red-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-6">
      {/* Header */}
      <div className="bg-[#2563EB] text-white px-6 pt-12 pb-8 rounded-b-3xl">
        <button
          onClick={() => navigate(`/result/${result.id}`)}
          className="flex items-center gap-2 text-white/90 hover:text-white mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back to Results</span>
        </button>
        <h1 className="text-3xl font-bold mb-2">Detailed Analysis</h1>
        <p className="text-blue-100">In-depth credibility breakdown</p>
      </div>

      <div className="px-6 -mt-6 space-y-4">
        {/* Source Credibility */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-[#2563EB]" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Source Credibility</h2>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-3">
              {getSourceIcon(result.sourceCredibility.status)}
              <div className="flex-1">
                <span
                  className={`inline-block px-3 py-1 rounded-full text-sm font-semibold border ${getSourceBadge(
                    result.sourceCredibility.status
                  )}`}
                >
                  {result.sourceCredibility.status.charAt(0).toUpperCase() +
                    result.sourceCredibility.status.slice(1)}
                </span>
              </div>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed">
              {result.sourceCredibility.description}
            </p>
          </div>
        </div>

        {/* Content Analysis */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6 text-purple-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Content Analysis</h2>
          </div>

          <div className="space-y-4">
            {/* Keywords */}
            <div>
              <p className="text-sm font-semibold text-gray-700 mb-2">Key Topics</p>
              <div className="flex flex-wrap gap-2">
                {result.contentAnalysis.keywords.map((keyword, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-blue-50 text-[#2563EB] rounded-full text-sm font-medium"
                  >
                    {keyword}
                  </span>
                ))}
              </div>
            </div>

            {/* Tone */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
              <span className="text-sm font-semibold text-gray-700">Tone</span>
              <span className="text-sm font-medium text-gray-900">{result.contentAnalysis.tone}</span>
            </div>

            {/* Bias */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
              <span className="text-sm font-semibold text-gray-700">Bias</span>
              <span className="text-sm font-medium text-gray-900">{result.contentAnalysis.bias}</span>
            </div>
          </div>
        </div>

        {/* Cross-check Results */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <Search className="w-6 h-6 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Cross-check Results</h2>
          </div>

          <div className="space-y-4">
            {/* Match Statistics */}
            <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-700">Sources Matched</span>
                <span className="text-2xl font-bold text-[#2563EB]">
                  {result.crossCheck.matched}/{result.crossCheck.total}
                </span>
              </div>
              <div className="h-2 bg-white rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#2563EB] rounded-full transition-all"
                  style={{ width: `${(result.crossCheck.matched / result.crossCheck.total) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Verified Sources */}
            <div>
              <p className="text-sm font-semibold text-gray-700 mb-3">Verified Sources</p>
              <div className="space-y-2">
                {result.crossCheck.sources.map((source, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-sm font-medium text-gray-900">{source}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Vietnamese Data Sources */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
              <Database className="w-6 h-6 text-orange-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Data Sources</h2>
          </div>

          <div className="space-y-3">
            <p className="text-sm text-gray-600 leading-relaxed">
              Analysis powered by data from Vietnamese news and social media platforms
            </p>
            <div className="space-y-2">
              {result.dataSources.map((source, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg">
                  <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0"></div>
                  <span className="text-sm font-medium text-gray-900">{source}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Analysis Timestamp */}
        <div className="text-center text-sm text-gray-500 pt-2 pb-4">
          Analyzed on {new Date(result.timestamp).toLocaleString()}
        </div>
      </div>
    </div>
  );
}