import { useNavigate } from "react-router";
import { Clock, CheckCircle, AlertTriangle, XCircle, Trash2 } from "lucide-react";
import { getAnalysisHistory } from "../utils/analysis";
import { useState } from "react";

export function HistoryScreen() {
  const navigate = useNavigate();
  const [history, setHistory] = useState(getAnalysisHistory());

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "trusted":
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case "suspicious":
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case "fake":
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "trusted":
        return "bg-green-50 border-green-200";
      case "suspicious":
        return "bg-yellow-50 border-yellow-200";
      case "fake":
        return "bg-red-50 border-red-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const clearHistory = () => {
    if (confirm("Are you sure you want to clear all history?")) {
      localStorage.removeItem("truthlens-history");
      setHistory([]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-6">
      {/* Header */}
      <div className="bg-[#2563EB] text-white px-6 pt-12 pb-8 rounded-b-3xl">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-3xl font-bold">History</h1>
          {history.length > 0 && (
            <button
              onClick={clearHistory}
              className="p-2 hover:bg-blue-600 rounded-lg transition-colors"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
        </div>
        <p className="text-blue-100">Your analysis history</p>
      </div>

      <div className="px-6 mt-6">
        {history.length === 0 ? (
          <div className="text-center mt-16">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-10 h-10 text-gray-400" />
            </div>
            <p className="text-gray-500 text-lg font-medium">No history yet</p>
            <p className="text-sm text-gray-400 mt-1">Start analyzing news to see your history</p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-gray-600">{history.length} total checks</p>
            </div>

            <div className="space-y-3">
              {history.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigate(`/result/${item.id}`)}
                  className={`w-full text-left bg-white border rounded-xl p-4 transition-all hover:shadow-md ${getStatusColor(
                    item.status
                  )}`}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">{getStatusIcon(item.status)}</div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 mb-1 line-clamp-2">{item.title}</p>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(item.timestamp).toLocaleDateString()}</span>
                        </div>
                        <span className="capitalize font-medium">{item.status}</span>
                        <span>{item.confidence}% confidence</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
