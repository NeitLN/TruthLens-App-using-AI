import { Outlet, NavLink } from "react-router";
import { Home, History, User } from "lucide-react";

export function Layout() {
  return (
    <div className="h-screen flex flex-col bg-gray-50 max-w-md mx-auto">
      {/* Main content */}
      <div className="flex-1 overflow-y-auto">
        <Outlet />
      </div>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around px-4 py-3">
          <NavLink
            to="/home"
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 px-6 py-2 rounded-lg transition-colors ${
                isActive
                  ? "text-[#2563EB] bg-blue-50"
                  : "text-gray-600 hover:text-[#2563EB]"
              }`
            }
          >
            <Home className="w-6 h-6" />
            <span className="text-xs font-medium">Home</span>
          </NavLink>

          <NavLink
            to="/history"
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 px-6 py-2 rounded-lg transition-colors ${
                isActive
                  ? "text-[#2563EB] bg-blue-50"
                  : "text-gray-600 hover:text-[#2563EB]"
              }`
            }
          >
            <History className="w-6 h-6" />
            <span className="text-xs font-medium">History</span>
          </NavLink>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 px-6 py-2 rounded-lg transition-colors ${
                isActive
                  ? "text-[#2563EB] bg-blue-50"
                  : "text-gray-600 hover:text-[#2563EB]"
              }`
            }
          >
            <User className="w-6 h-6" />
            <span className="text-xs font-medium">Profile</span>
          </NavLink>
        </div>
      </nav>
    </div>
  );
}
