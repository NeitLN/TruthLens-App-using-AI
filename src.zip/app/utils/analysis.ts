export type AnalysisStatus = "trusted" | "suspicious" | "fake";

export interface AnalysisResult {
  id: string;
  title: string;
  content: string;
  status: AnalysisStatus;
  confidence: number;
  explanation: string;
  timestamp: number;
  sourceCredibility: {
    status: "trusted" | "unknown" | "blacklisted";
    description: string;
  };
  contentAnalysis: {
    keywords: string[];
    tone: string;
    bias: string;
  };
  crossCheck: {
    matched: number;
    total: number;
    sources: string[];
  };
  dataSources: string[]; // Added Vietnamese data sources
}

// Mock AI analysis function
export function analyzeContent(input: string): AnalysisResult {
  // Simulate AI analysis with random results for demo
  const statuses: AnalysisStatus[] = ["trusted", "suspicious", "fake"];
  const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
  
  const explanations = {
    trusted: "This article comes from a verified source and contains factual information supported by multiple credible outlets.",
    suspicious: "This content shows mixed signals. Some claims could not be verified independently.",
    fake: "This article comes from an unverified source and contains misleading claims.",
  };

  const sourceStatuses: Array<"trusted" | "unknown" | "blacklisted"> = ["trusted", "unknown", "blacklisted"];
  const randomSourceStatus = sourceStatuses[Math.floor(Math.random() * sourceStatuses.length)];

  const tones = ["Neutral", "Sensational", "Balanced", "Biased"];
  const biases = ["Center", "Left-leaning", "Right-leaning", "Extreme"];
  
  // Vietnamese news sources and social media platforms
  const vietnameseNewsSources = [
    "VnExpress", "Thanh Niên", "Tuổi Trẻ", "Dân Trí", 
    "Vietnamnet", "Báo Mới", "Zing News"
  ];
  
  const vietnameseSocialPlatforms = [
    "Facebook Vietnam", "Zalo", "TikTok Vietnam"
  ];
  
  // Randomly select 3-5 Vietnamese sources
  const allSources = [...vietnameseNewsSources, ...vietnameseSocialPlatforms];
  const selectedSources = allSources
    .sort(() => 0.5 - Math.random())
    .slice(0, Math.floor(Math.random() * 3) + 3);
  
  return {
    id: Date.now().toString(),
    title: input.substring(0, 60) + (input.length > 60 ? "..." : ""),
    content: input,
    status: randomStatus,
    confidence: Math.floor(Math.random() * 30) + 70, // 70-100
    explanation: explanations[randomStatus],
    timestamp: Date.now(),
    sourceCredibility: {
      status: randomSourceStatus,
      description: randomSourceStatus === "trusted" 
        ? "Verified news source with strong editorial standards"
        : randomSourceStatus === "unknown"
        ? "Source has limited verification history"
        : "Source has been flagged for misinformation",
    },
    contentAnalysis: {
      keywords: ["politics", "economy", "technology", "health"].slice(0, Math.floor(Math.random() * 3) + 2),
      tone: tones[Math.floor(Math.random() * tones.length)],
      bias: biases[Math.floor(Math.random() * biases.length)],
    },
    crossCheck: {
      matched: Math.floor(Math.random() * 10) + 1,
      total: 15,
      sources: ["Reuters", "AP News", "BBC", "The Guardian"].slice(0, Math.floor(Math.random() * 3) + 1),
    },
    dataSources: selectedSources, // Added Vietnamese data sources
  };
}

// LocalStorage helpers
export function saveAnalysis(result: AnalysisResult): void {
  const results = getAnalysisHistory();
  results.unshift(result);
  localStorage.setItem("truthlens-history", JSON.stringify(results.slice(0, 50))); // Keep last 50
}

export function getAnalysisHistory(): AnalysisResult[] {
  const data = localStorage.getItem("truthlens-history");
  return data ? JSON.parse(data) : [];
}

export function getAnalysisById(id: string): AnalysisResult | null {
  const results = getAnalysisHistory();
  return results.find((r) => r.id === id) || null;
}